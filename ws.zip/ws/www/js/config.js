
angular.module('cucikan-config', [])
		.constant('CONFIG', 
			{
				SERVER: 'http://cucikan.com/',

				API_PHP: 'ws/',

				APP_ID: 'com.cucikan.client',
				APP_NAME: 'CUCLIENT',
				APP_VERSION: '1.0.0',

			}
		);