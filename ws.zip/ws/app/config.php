<?php

if (!defined('SAFELOAD'))
    exit('ACCESS FORBIDDEN!');

class Config{
    static $SERVER = 'localhost';
    static $USER = 'root';
    static $PASS = '';
    static $DB = 'cucikan';
}